entrada = raw_input('>>>')
print entrada

