matrox = ("matrix",'perro',10)
print matrox[2]

print matrox[1] + str(matrox[2]) + matrox[0]

tupla = ('perro','gato')
print tupla

tupla = ('gato')
print tupla

tupla = ('gato',)
print tupla

diccionario = {'primero':'gato','segundo':'perro'}
print diccionario
print tupla[0]
print diccionario['primero']

tupla = ('perro','gato',)
diccionario ={'1':1,'primero':'gato','segundo':'perro'}
print diccionario
print tupla[0]
print diccionario['primero']
