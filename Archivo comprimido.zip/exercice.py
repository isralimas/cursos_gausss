suma = 0
while True:
	entrada = raw_input('>>>')
	if entrada == 'salida':
		break
	suma = suma + int(entrada)
	print suma

